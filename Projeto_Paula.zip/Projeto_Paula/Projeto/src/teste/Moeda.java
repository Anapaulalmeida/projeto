package teste;

import java.util.Objects;

public abstract class Moeda {
    protected double valor;

    public Moeda(double valor) {
        this.valor = valor;
    }

    public double getValue() {
        return valor;
    }

    public abstract double conversaoReal();

    
  	@Override
  	public boolean equals(Object obj) {
      if (this == obj) return true;
      if (obj == null || getClass() != obj.getClass()) return false;
      Moeda moeda = (Moeda) obj; 
      return Double.compare(moeda.getValue(), getValue()) == 0;
  }}
