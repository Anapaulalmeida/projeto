package teste;

import java.util.ArrayList;
import java.util.List;

public class Cofrinho {
    private List<Moeda> mCorrente; // moeda corrente

    public Cofrinho() {
        mCorrente = new ArrayList<>();
    }

    public void adMoeda(Moeda moeda) { // adicionar dinheiro
        mCorrente.add(moeda);
    }

    public void reMoeda(Moeda moeda) { // remover dinheiro
        mCorrente.remove(moeda);
    }

    public void listaMoeda() {
        for (Moeda moeda : mCorrente) {
            System.out.println(moeda.getClass().getSimpleName() + ": " + moeda.getValue());
        }
    }

    public double calcularReal() {
        double total = 0;
        for (Moeda moeda : mCorrente) {
            total += moeda.conversaoReal();
        }
        return total;
    }
}