package teste;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Cofrinho cofrinho = new Cofrinho();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("MENU COFRINHO");
            System.out.println("1 - ADICIONAR MOEDA");
            System.out.println("2 - REMOVER MOEDA");
            System.out.println("3 - EXIBIR TODAS MOEDAS");
            System.out.println("4 - CONVERTER AO REAL");
            System.out.println("0 - SAIR");

            System.out.print("-");
            int menuPrincipal = scanner.nextInt();

            switch (menuPrincipal) {
            case 1: { 
                System.out.println("ESCOLHA UMA MOEDA");
                System.out.println("1 - REAL");
                System.out.println("2 - EURO");
                System.out.println("3 - DÓLAR");
                System.out.println("-");
                int menuAdicMoeda = scanner.nextInt();
                System.out.println("-");
                double valor = scanner.nextDouble();

                switch (menuAdicMoeda) { 
                    case 1:
                        cofrinho.adMoeda(new Real(valor));
                        break;
                    case 2:
                        cofrinho.adMoeda(new Euro(valor));
                        break;
                    case 3:
                        cofrinho.adMoeda(new Dolar(valor));
                        break;
                    default: 
                        System.out.println("MOEDA INVÁLIDA.");
                }
                break;
    	            }
                case 2: { 
	                System.out.println("ESCOLHA UMA MOEDA.");
	                System.out.println("1 - REAL");
	                System.out.println("2 - EURO");
	                System.out.println("3 - DÓLAR");
	                System.out.println("-");
	                int menuRemMoeda = scanner.nextInt();
	                System.out.println("-");
	                double valor = scanner.nextDouble();

	                switch (menuRemMoeda) { 
	                    case 1:
	                        cofrinho.reMoeda(new Real(valor));
	                        break;
	                    case 2:
	                        cofrinho.reMoeda(new Euro(valor));
	                        break;
	                    case 3:
	                        cofrinho.reMoeda(new Dolar(valor));
	                        break;
	                    default: 
	                        System.out.println("MOEDA INVÁLIDA.");
	                }
	                break;}

                case 3:
                    cofrinho.listaMoeda();
                    break;

                case 4:
                    System.out.println("CONVERTIDO: " + cofrinho.calcularReal());
                    break;

                case 0:
                    System.out.println("ENCERRADO.");
                    return;

                default:
                    System.out.println("OPÇÃO INVÁLIDA.");
                    
                
            }
        }
    }
}