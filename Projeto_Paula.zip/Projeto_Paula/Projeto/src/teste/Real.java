package teste;

public class Real extends Moeda {
    public Real(double valor) {
        super(valor);
    }

    @Override
    public double conversaoReal() {
        return valor;
    }
}
