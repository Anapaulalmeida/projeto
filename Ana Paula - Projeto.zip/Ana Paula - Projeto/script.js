window.addEventListener('DOMContentLoaded', () => {
  const main = document.getElementById('conteudo');

  function carregarSecao(secao) {
    let html = '';

    if (secao === 'sobre') {
      html = `
        <h1>Sobre Mim</h1>
        <p>Olá, Meu nome é Ana Paula.</p>
        <p>Eu gosto de viajar, ver filmes, e festas.</p>
      `;
    } else if (secao === 'formacao') {
      html = `
        <h1>Formação Educacional</h1>
        <p>Eu sou Técnica em Eletrônica.</p>
      `;
    } else if (secao === 'portfolio') {
      html = `
        <h1>Projeto</h1>
        <p>Aqui está um projeto que desenvolvi durante o percorrer das aulas:</p>
        <ul>
          <li><a href="tabela/exemplo1.html" target="_blank">Tabela de Preços</a></li>
        </ul>
      `;
    } else if (secao === 'contato') {
      html = `
        <h1>Contato</h1>
        <form id="form-contato">
          <label for="nome">Nome:</label>
          <input type="text" id="nome" required placeholder="Seu nome"/>

          <label for="email">Email:</label>
          <input type="email" id="email" required placeholder="seu@email.com"/>

          <label for="mensagem">Mensagem:</label>
          <textarea id="mensagem" required placeholder="Escreva sua mensagem..."></textarea>

          <button type="submit">Enviar</button>
        </form>
      `;
    } else {
      html = `
        <h1>Bem-vindo ao Portfólio de Ana Paula</h1>
        <p>Use o menu acima para navegar pelas seções.</p>
      `;
    }

    main.innerHTML = html;

    if (secao === 'contato') {
      const form = document.getElementById('form-contato');
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        alert('Mensagem enviada.');
        form.reset();
      });
    }
  }

  function atualizarSecao() {
    const hash = window.location.hash.replace('#', '') || 'sobre';
    carregarSecao(hash);
  }

  document.querySelectorAll('.menu a').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const destino = link.getAttribute('href');
      window.location.hash = destino;
    });
  });

  window.addEventListener('hashchange', atualizarSecao);

  atualizarSecao();
});
